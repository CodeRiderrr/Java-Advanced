package parrots;

import java.util.ArrayList;
import java.util.List;

public class Cage {

    private String name;
    private int capacity;
    private List<Parrot>data;

    public Cage(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.data = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public int getCapacity() {
        return capacity;
    }

    public List<Parrot> getData() {
        return data;
    }
    public void add(Parrot parrot){
        if (this.getCapacity() > this.getData().size()){
            this.data.add(parrot);
        }
    }
    public boolean remove(String name){
        for (Parrot parrot : data){
            if (parrot.getName().equals(name)) {
                this.data.remove(parrot);
                return true;
            }
        }
        return false;
    }
    public Parrot sellParrot(String name){
        for (Parrot parrot : data){
            if (parrot.getName().equals(name)) {
                parrot.setAvailable(false);
                return parrot;
            }
        }
        return null;
    }
    public List<Parrot> sellParrotBySpecies(String species){
        List<Parrot>soldSpecies = new ArrayList<>();
        for (Parrot parrot : data){
            if (parrot.getSpecies().equals(species)){
                soldSpecies.add(parrot);
            }
        }
//        for (Parrot parrot1 : soldSpecies){
//            for (Parrot parrot : data){
//                if (parrot.getName().equals(parrot1.getName())){
//                    this.getData().remove(parrot);
//                }
//            }
//        }
        return soldSpecies;
    }
    public int count(){
        return this.getData().size();
    }
    public String report(){
        StringBuilder builder = new StringBuilder();
        builder.append(String.format("Parrots available at %s:\n",getName()));
        for(Parrot parrot : data){
            if (parrot.isAvailable()){
                builder.append(parrot).append(System.lineSeparator());
            }
        }
        return builder.toString();
    }
}
